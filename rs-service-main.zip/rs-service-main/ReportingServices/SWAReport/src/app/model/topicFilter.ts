export interface TopicFilter{
    startDateTime: number;
    endDateTime: number;
    actionType: String
    topicName: string
}