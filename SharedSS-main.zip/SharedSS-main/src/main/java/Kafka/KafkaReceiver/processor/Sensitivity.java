package Kafka.KafkaReceiver.processor;

public class Sensitivity {
    private int index = 0;
    public void setIndex(int index) {
        this.index = index;
    }
    public int getIndex() {
        return index;
    }
}
