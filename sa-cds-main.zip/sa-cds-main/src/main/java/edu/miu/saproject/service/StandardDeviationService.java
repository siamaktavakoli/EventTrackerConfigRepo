package edu.miu.saproject.service;

public interface StandardDeviationService {

    void findDataChange(Long dataSource);
}

