package edu.miu.saproject;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SaProjectApplication {

    public static void main(String[] args) {
        SpringApplication.run(SaProjectApplication.class, args);
    }

}
