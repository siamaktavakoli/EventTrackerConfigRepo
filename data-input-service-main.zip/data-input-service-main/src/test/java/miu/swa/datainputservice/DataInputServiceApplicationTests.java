package miu.swa.datainputservice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DataInputServiceApplicationTests {

    @Test
    void contextLoads() {
    }

}
